<?php
class Login {

    private $mysqli;

    function __construct($conn){
        $this->mysqli = $conn;
    }

    public function register($nmd_log, $nmb_log, $email_log, $pass_log) {
        $db = $this->mysqli->conn;
        $db->query("INSERT INTO tb_login VALUES ('', '$nmd_log', '$nmb_log', '$email_log', '$pass_log')") or die ($db->error);

    }
    public function login($email_log, $pass_log) {
        $db = $this->mysqli->conn;
        $sql = $db->query("SELECT * FROM tb_login WHERE email_login='$email_log' AND pass_login= md5('$pass_log') ") or die ($db->error);
        $cek = num_rows($sql);
        echo "kontol";
    }
    function __destruct(){
        $db = $this->mysqli->conn;
        $db->close();
    }
}
?>
<?php
ob_start();
require_once('../config/+koneksi.php');
require_once('../model/database.php');

include "../model/m_barang.php";
$connection = new Database($host, $user, $pass, $database);
$brg = new Barang($connection);

$id_brg = $_POST['id_brg'];
$nm_brg = $connection->conn->real_escape_string($_POST['nm_brg']);
$hrg_brg = $connection->conn->real_escape_string($_POST['hrg_brg']);
$jns_brg = $connection->conn->real_escape_string($_POST['jns_brg']);
$lnk_brg = $connection->conn->real_escape_string($_POST['lnk_brg']);
$dsc_brg = $connection->conn->real_escape_string($_POST['dsc_brg']);

$pict = $_FILES['gbr_brg']['name'];
$extensi = explode(".", $_FILES['gbr_brg']['name']);
$gbr_brg = "brg-".round(microtime(true)).".".end($extensi);
$sumber = $_FILES['gbr_brg']['tmp_name'];

if ($pict == '') {
    $brg->edit("UPDATE tb_barang SET nama_brg = '$nm_brg', harga_brg = '$hrg_brg', jenis_brg = '$jns_brg', desc_brg = '$dsc_brg', link_brg = '$lnk_brg' WHERE id_brg = '$id_brg' ");
} else {
    $gbr_awal = $brg->tampil($id_brg)->fetch_object()->gbr_brg;
    unlink("../assets/img/barang/".$gbr_awal);

    $upload = move_uploaded_file($sumber, "../assets/img/barang/".$gbr_brg);
    if($upload){
        $brg->edit("UPDATE tb_barang SET nama_brg = '$nm_brg', harga_brg = '$hrg_brg', jenis_brg = '$jns_brg', gbr_brg = '$gbr_brg', desc_brg = '$dsc_brg', link_brg = '$lnk_brg' WHERE id_brg = '$id_brg' ");
        //echo "<div id=\"sukses\" class=\"alert alert-success\" role=\"alert\">";
        //echo "Update data sukses! <a href=\"?page=barang\" class=\"alert-link\">click disini untuk kembali ke tabel</a>";
        //echo "</div>";
    } else {
        echo "<script>alert('Upload gambar gagal!')</script>";
    }
}
?>
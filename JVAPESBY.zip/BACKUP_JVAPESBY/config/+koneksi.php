<?php
$host = "mysql.hostinger.co.id";
$user = "u712644960_admin";
$pass = "Ddplhs1";
$database = "u712644960_admin";
?>
<?php
include "model/m_login.php";
require_once('config/+koneksi.php');
$log = new Login($connection);
?>
<div class="card card-register mx-auto mt-5">
  <div class="card-header">Register an Account</div>
    <div class="card-body">
        <form>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="nmd_log">First name</label>
                <input class="form-control" name="nmd_log" id="nmd_log" type="text" aria-describedby="nameHelp" placeholder="Enter first name" required>
              </div>
              <div class="col-md-6">
                <label for="nmb_log">Last name</label>
                <input class="form-control" name="nmb_log" id="nmb_log" type="text" aria-describedby="nameHelp" placeholder="Enter last name" required>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="email_log">Email address</label>
            <input class="form-control" name="email_log" id="email_log" type="email" aria-describedby="emailHelp" placeholder="Enter email" required>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="pass_log">Password</label>
                <input class="form-control" name="pass_log" id="pass_log" type="password" placeholder="Password" required>
              </div>
              <div class="col-md-6">
                <label for="passc_log">Confirm password</label>
                <input class="form-control" name="passc_log" id="passc_log" type="password" placeholder="Confirm password" required>
              </div>
            </div>
          </div>
          <input type="submit" class="btn btn-primary btn-block" name="register" value="Register">
              <?php
                if(@$_POST['register']){
                  $nmd_log = $_POST['nmd_log'];
                  $nmb_log = $_POST['nmb_log'];
                  $email_log = $_POST['email_log'];
                  $pass_log = md5($_POST['pass_log']);
                  $passc_log = mdt($_POST['passc_log']);
                  
                    $log->tambah($nmd_log, $nmb_log, $email_log, $pass_log);
                    header("location: ?page=signin");
                }
              ?>
        </form>
      <div class="text-center">
        <a class="d-block small mt-3" href="?page=signin">Login Page</a>
        <a class="d-block small" href="forgot-password.html">Forgot Password?</a>
      </div>
    </div>
</div>
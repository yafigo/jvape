<?php
include "model/m_barang.php";

$brg = new Barang($connection);

if(@$_GET['act'] == ''){
?>
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#"><i class="fa fa-fw fa-shopping-cart"></i> Barang</a>
    </li>
    <li class="breadcrumb-item active">Data Barang</li>
</ol>
<div class="row">
    <div class="col-12">
        <h1>Barang</h1>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="table table-responsive">
        <table width="100%" class="table table-bordered table-hover table-striped" id="datatables" cellspacing="0" >
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama Barang</th>
                    <th>Harga Barang</th>
                    <th>Jenis Barang</th>
                    <th>Link Barang</th>
                    <th>Deskripsi Barang</th>
                    <th>Gambar Barang</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <!-- TAMPILIN OBJEKNYA DISINI-->
                <?php
                $no = 1;
                $tampil = $brg->tampil();
                while ($data = $tampil->fetch_object()){
                ?>
                
                <tr>
                    <td align="center"><?php echo $no++; ?></td> <!-- NOMORNYA -->
                    <td><?php echo $data->nama_brg ?></td> <!-- NAMA BARANG -->
                    <td><?php echo $data->harga_brg ?></td> <!-- HARGA BARANG -->
                    <td><?php echo $data->jenis_brg ?></td> <!-- jenis BARANG -->
                    <td><?php echo $data->link_brg ?></td> <!-- link BARANG -->
                    <td><?php echo $data->desc_brg ?></td> <!-- deskripsi BARANG -->
                    <td align="center">
                        <img src="assets/img/barang/<?php echo $data->gbr_brg; ?>" width="70px"></img>
                    </td> <!-- GAMBAR BARANGNYA-->
                    <td align="center">
                        <a id="edit_brg" data-toggle="modal" data-target="#edit" data-id="<?php echo $data->id_brg;?>"
                                                                                    data-nama="<?php echo $data->nama_brg;?>"
                                                                                    data-harga="<?php echo $data->harga_brg;?>"
                                                                                    data-jenis="<?php echo $data->jenis_brg;?>"
                                                                                    data-link="<?php echo $data->link_brg;?>"
                                                                                    data-desc="<?php echo $data->desc_brg;?>"
                                                                                    data-gbr="<?php echo $data->gbr_brg;?>">
                        <button class="btn btn-info btn-sm"><i class="fa fa-edit"></i>Edit</button>
                        </a>
                        <a href="?page=barang&act=del&id=<?php echo $data->id_brg; ?>" onclick="return confirm('Yakin ingin menghapus data ini?')">
                        <button class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i> Hapus</button>
                        </a>
                    </td>
                </tr>
                <!-- SAMBUNG DISINI -->
                <?php
                }
                ?>
            </tbody>
        </table>
        </div>

        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#tambah">Tambah Data</button>

        <!---=====================================.= MODAL BUAT TAMBAH DATA ===========================================-->
        <div id="tambah" role="dialog" class="modal fade" tabindex="-1" aria-labelledby="tambahLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="tambahLabel">Tambah Data Barang</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="nm_brg" class="control-label">Nama Barang</label>
                                <input type="text" name="nm_brg" id="nm_brg" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="hrg_brg" class="control-label">Harga Barang</label>
                                <input type="number" name="hrg_brg" id="hrg_brg" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="jns_brg" class="control-label">Jenis Barang</label>
                                <input type="text" name="jns_brg" id="jns_brg" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="lnk" class="control-label">Link Barang</label>
                                <input type="text" name="lnk_brg" id="lnk_brg" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="dsc_brg" class="control-label">Deskripsi Barang</label>
                                <textarea  type="text" name="dsc_brg" id="dsc_brg" class="form-control" rows="3"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="gbr_brg" class="control-label">Gambar Barang</label>
                                <input type="file" name="gbr_brg" id="gbr_brg" class="form-control" required>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-danger" type="reset" >Reset</button>
                            <input type="submit" class="btn btn-primary" name="simpan" value="Simpan">
                        </div>
                    </form>
                    <?php
                    if(@$_POST['simpan']){
                        $nm_brg = $connection->conn->real_escape_string($_POST['nm_brg']);
                        $hrg_brg = $connection->conn->real_escape_string($_POST['hrg_brg']);
                        $jns_brg = $connection->conn->real_escape_string($_POST['jns_brg']);
                        $lnk_brg = $connection->conn->real_escape_string($_POST['lnk_brg']);
                        $dsc_brg = $connection->conn->real_escape_string($_POST['dsc_brg']);

                        $extensi = explode(".", $_FILES['gbr_brg']['name']);
                        $gbr_brg = "brg-".round(microtime(true)).".".end($extensi);
                        $sumber = $_FILES['gbr_brg']['tmp_name'];

                        $upload = move_uploaded_file($sumber, "assets/img/barang/".$gbr_brg);
                        if($upload){
                            $brg->tambah($nm_brg, $hrg_brg, $jns_brg, $gbr_brg, $lnk_brg, $dsc_brg);
                            header("location: ?page=barang");
                        } else {
                            echo "<script>alert('Upload gambar gagal!')</script>";
                        }
                        
                    }
                    ?>
                </div>
            </div>
        </div>
        <!---====================================== MODAL BUAT TAMBAH DATA ===========================================-->

        <!---====================================== MODAL EDIT TAMBAH DATA ===========================================-->
        <div id="edit" role="dialog" class="modal fade" tabindex="-1" aria-labelledby="editLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="editLabel">Edit Data Barang</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <form id="form" method="post" enctype="multipart/form-data">
                        <div class="modal-body" id="modal-edit" >
                            <div class="form-group">
                                <label for="nm_brg" class="control-label">Nama Barang</label>
                                <input type="hidden" name="id_brg" id="id_brg">
                                <input type="text" name="nm_brg" id="nm_brg" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="hrg_brg" class="control-label">Harga Barang</label>
                                <input type="number" name="hrg_brg" id="hrg_brg" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="jns_brg" class="control-label">Jenis Barang</label>
                                <input type="text" name="jns_brg" id="jns_brg" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="lnk" class="control-label">Link Barang</label>
                                <input type="text" name="lnk_brg" id="lnk_brg" class="form-control" >
                            </div>
                            <div class="form-group">
                                <label for="dsc_brg" class="control-label">Deskripsi Barang</label>
                                <textarea type="text" name="dsc_brg" id="dsc_brg" class="form-control"rows="3"></textarea>
                            </div>
                            <div class="form-group">
                                <label for="gbr_brg" class="control-label">Gambar Barang</label>
                                <div style="padding-bottom:5px" align="center">
                                    <img src="" width="80px" id="pict">
                                </div>
                                <input type="file" name="gbr_brg" id="gbr_brg" class="form-control">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input type="submit" class="btn btn-primary" name="edit" value="Simpan">
                        </div>
                    </form>
                    <script type="text/javascript" src="assets/vendor/jquery/jquery.min.js"></script>
                    <script type="text/javascript">
                    $(document).on("click", "#edit_brg", function() {
                        var idbrg = $(this).data('id'); 
                        var nmbrg = $(this).data('nama');
                        var hrgbrg = $(this).data('harga');
                        var stkbrg = $(this).data('jenis');
                        var lnkbrg = $(this).data('link');
                        var dscbrg = $(this).data('desc');
                        var gbrbrg = $(this).data('gbr');

                        $("#modal-edit #id_brg").val(idbrg);
                        $("#modal-edit #nm_brg").val(nmbrg);
                        $("#modal-edit #hrg_brg").val(hrgbrg);
                        $("#modal-edit #jns_brg").val(stkbrg);
                        $("#modal-edit #lnk_brg").val(lnkbrg);
                        $("#modal-edit #dsc_brg").val(dscbrg);
                        $("#modal-edit #pict").attr("src", "assets/img/barang/"+gbrbrg);
                        $("#edit .modal").addClass("hidden");
                        
                    })

                    $(document).ready(function(e) {
                        $("#form").on("submit", (function(e){
                            e.preventDefault();
                            $.ajax({
                                url : 'model/edit_barang.php',
                                type : 'POST',
                                data : new FormData(this),
                                contentType : false,
                                cachce : false,
                                processData : false,
                                success : function(msg) {
                                    $('.table').html(msg);
                                }
                            });
                            setTimeout(function(){
                                window.location = "?page=barang&act=edit"
                            }, 2000);
                        }));
                    })
                    </script>
                </div>
            </div>
        </div>
        <!---====================================== MODAL BUAT EDIT DATA ===========================================-->
    </div>
</div>
<?php
} else if (@$_GET['act'] == 'del'){
    $gbr_awal = $brg->tampil($_GET['id'])->fetch_object()->gbr_brg;
    unlink("assets/img/barang/".$gbr_awal);

    $brg->hapus($_GET['id']);
    header("location: ?page=barang");
} else if (@$_GET['act'] == 'edit'){
    echo "<div class=\"alert alert-success\" role=\"alert\">";
    echo "<h4 class=\"alert-heading\">Update data sukses!</h4>";
    echo "<p>Data berhasil di update! silahkan kembali ke tabel barang untuk memastikan kembali apakah data benar-benar berhasil tersimpan</p>";
    echo "<hr>";
    echo "<p class=\"mb-0\"><a href=\"?page=barang\">Click disini untuk kembali ke tabel barang</a></p>";
    echo "</div>";
}
?>
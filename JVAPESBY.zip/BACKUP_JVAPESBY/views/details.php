<?php
include "model/m_barang.php";
$brg = new Barang($connection);

if(@$_GET['id'] != ''){
?>
<!-- Hero Section-->
<?php
$tampil = $brg->tampil(@$_GET['id']);
while ($data = $tampil->fetch_object())
{ 
?>
<section class="hero hero-page padding-small">
    <div class="container">
    <div class="row d-flex">
        <div class="col-md-9 order-2 order-md-1"></div>
        <ul class="breadcrumb d-flex justify-content-start justify-content-md-center col-md-3 text-right order-1 order-md-2">
        <li class="breadcrumb-item"><a href="?page=card">Home</a></li>
        <li class="breadcrumb-item active"><?php echo $data->nama_brg; ?></li>
        </ul>
    </div>
    </div>
</section>
<section class="product-details no-padding-top">
    <div class="container">
    <div class="row">
        <div class="product-images col-lg-6">
        <div data-slider-id="1" class="owl-carousel items-slider owl-drag">
            <div class="item"><img src="assets/img/barang/<?php echo $data->gbr_brg; ?>" alt="shirt"></div>
        </div>
        </div>
        <div class="details col-lg-6">
        <h2 class="nama-detail" ><?php echo $data->nama_brg; ?></h2>
        <div class="d-flex align-items-center justify-content-between flex-column flex-sm-row">
            <ul class="price list-inline no-margin">
            <li class="list-inline-item current">Rp<?php echo $data->harga_brg; ?></li>
            </ul>
            <div class="review d-flex align-items-center">
            <ul class="rate list-inline">
                <li class="list-inline-item"><i class="fa fa-star-o text-primary"></i></li>
                <li class="list-inline-item"><i class="fa fa-star-o text-primary"></i></li>
                <li class="list-inline-item"><i class="fa fa-star-o text-primary"></i></li>
                <li class="list-inline-item"><i class="fa fa-star-o text-primary"></i></li>
                <li class="list-inline-item"><i class="fa fa-star-o text-primary"></i></li>
            </div>
        </div>
        <p><?php echo $data->desc_brg; ?></p>
        <ul class="CTAs list-inline">
            <li class="list-inline-item"><a href="<?php echo $data->link_brg; ?>" class="btn btn-template wide"> <i class="icon-cart"></i>Add to Cart</a></li>
        </ul>
        </div>
    </div>
    </div>
</section>
<section class="product-description no-padding">
    <div class="container">
    <ul role="tablist" class="nav nav-tabs">
        <li class="nav-item"><a data-toggle="tab" href="#description" role="tab" class="nav-link active">Description</a></li>
    </ul>
    <div class="tab-content">
        <div id="description" role="tabpanel" class="tab-pane active">
        <p><?php echo $data->desc_brg; ?></p>
        </div>
    </div>
    </div>
    <div class="container-fluid">
    <div class="share-product gray-bg d-flex align-items-center justify-content-center flex-column flex-md-row"><strong class="text-uppercase">Share this on</strong>
        <ul class="list-inline text-center">
        <li class="list-inline-item"><a href="#" target="_blank" title="twitter"><i class="fa fa-twitter"></i></a></li>
        <li class="list-inline-item"><a href="#" target="_blank" title="facebook"><i class="fa fa-facebook"></i></a></li>
        <li class="list-inline-item"><a href="#" target="_blank" title="instagram"><i class="fa fa-instagram"></i></a></li>
        <li class="list-inline-item"><a href="#" target="_blank" title="pinterest"><i class="fa fa-pinterest"></i></a></li>
        <li class="list-inline-item"><a href="#" target="_blank" title="vimeo"><i class="fa fa-vimeo"></i></a></li>
        </ul>
    </div>
    </div>
</section>
<?php
}
?>
<?php
} else if (@$_GET['id'] == '') {
    header("location: ?page=card");
}
?>
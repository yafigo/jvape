<?php
@session_start;
include "model/m_login.php";
$log = new Login($connection);
?>
<div class="card card-login mx-auto mt-5">
      <div class="card-header">JVape Login</div>
          <div class="card-body">
              <form action="" method="post">
              <div class="form-group">
                  <label for="email_log">Email</label>
                  <input class="form-control" name="email_log" id="email_log" type="text" aria-describedby="emailHelp" placeholder="Enter email">
              </div>
              <div class="form-group">
                  <label for="exampleInputPassword1">Password</label>
                  <input class="form-control" name="pass_log" id="pass_log" type="password" placeholder="Password">
              </div>
              <div class="form-group">
                  <div class="form-check">
                  <label class="form-check-label">
                      <input class="form-check-input" type="checkbox"> Remember Password</label>
                  </div>
              </div>
              <input type="submit" class="btn btn-primary btn-block" name="signin" value="Login">
              </form>
              <?php
                if(@$_POST['signin']){
                $username = @$_POST['email_log'];
                $password = md5(@$_POST['pass_log']);
                    if($username=="admin" && $password=="21232f297a57a5a743894a0e4a801fc3"){
                        session_start();
                        $_SESSION["user"] = $user;
                        header("location: back.php");
                    } else {
                        echo "<script>alert('Salah damang!')</script>";
                    }
                }   
              ?>
        <div class="text-center">
    </div>
</div>
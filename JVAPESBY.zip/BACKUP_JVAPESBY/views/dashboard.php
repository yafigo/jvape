<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="index.html">Dashboard</a>
    </li>
</ol>
<div class="row">
    <div class="col-12">
        <h1>Dashboard</h1>
        <p>This is an example of a Dashboard</p>
    </div>
</div>
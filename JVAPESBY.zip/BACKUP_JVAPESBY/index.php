<?php
ob_start();
require_once('config/+koneksi.php');
require_once('model/database.php');

$connection = new Database($host, $user, $pass, $database);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>JVape Jemursari Vapor Store</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/font-awesome/css/font-awesome.min.css">
    <!-- Bootstrap Select-->
    <link rel="stylesheet" href="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/bootstrap-select/css/bootstrap-select.min.css">
    <!-- Price Slider Stylesheets -->
    <link rel="stylesheet" href="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/nouislider/nouislider.css">
    <!-- Custom font icons-->
    <link rel="stylesheet" href="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/css/custom-fonticons.css">
    <!-- Google fonts - Poppins-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700">
    <!-- owl carousel-->
    <link rel="stylesheet" href="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/owl.carousel/assets/owl.carousel.css">
    <link rel="stylesheet" href="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/owl.carousel/assets/owl.theme.default.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="assets/css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link href="assets/css/style.css" rel="stylesheet">
    <!-- Favicon-->
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <!-- Modernizr-->
    <script src="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/js/modernizr.custom.79639.js"></script>
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <!-- navbar-->
    <header class="header">
        <!-- Tob Bar-->
        <nav class="navbar navbar-expand-lg">
            <div class="search-area">
                <div class="search-area-inner d-flex align-items-center justify-content-center">
                <div class="close-btn"><i class="icon-close"></i></div>
                <form action="#">
                    <div class="form-group">
                    <input type="search" name="search" id="search" placeholder="What are you looking for?">
                    <button type="submit" class="submit"><i class="icon-search"></i></button>
                    </div>
                </form>
                </div>
            </div>
            <div class="container-fluid">  
                <!-- Navbar Header  --><a href="back.php" class="navbar-brand"><img src="assets/img/logo2.png" alt="..."></a>
                <button type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler navbar-toggler-right"><i class="fa fa-bars"></i></button>
                <!-- Navbar Collapse -->
                <div id="navbarCollapse" class="collapse navbar-collapse">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a href="?page=card" class="nav-link active">Home</a>
                    </li>
                    <li class="nav-item"><a href="?page=shop" class="nav-link">Shop</a>
                    </li>
                    <li class="nav-item"><a href="?page=contact" class="nav-link">Contact</a>
                    </li>
                </ul>
                <div class="right-col d-flex align-items-lg-center flex-column flex-lg-row">
                    </div>
                </div>
                </div>
            </div>
        </nav>
    </header>
    <!-- Men's Collection -->
    <?php 
    if(@$_GET['page'] == 'card' || @$_GET['page'] == '') {
        include "views/card.php";
    } else if (@$_GET['page'] == 'shop') {
        include "views/shop.php";
    } else if (@$_GET['page'] == 'contact') {
      include "views/contact.php";
    }
    else if (@$_GET['page'] == 'detail') {
      include "views/details.php";
    }
    ?>
    <!-- Men's Collection [END]-->
    <div id="scrollTop"><i class="fa fa-long-arrow-up"></i></div>
    <!-- Footer-->
    <footer class="main-footer">
      <!-- Service Block-->
      <div class="services-block">
        <div class="container">
          <div class="row">
            <div class="col-lg-4 d-flex justify-content-center justify-content-lg-start">
              <div class="item d-flex align-items-center">
                <div class="icon"><i class="icon-truck"></i></div>
                <div class="text">
                  <h6 class="no-margin text-uppercase">Gojek partner shipping</h6>
                </div>
              </div>
            </div>
            <div class="col-lg-4 d-flex justify-content-center">
              <div class="item d-flex align-items-center">
                <div class="icon"><i class="icon-coin"></i></div>
                <div class="text">
                  <h6 class="no-margin text-uppercase">Money back guarantee</h6>
                </div>
              </div>
            </div>
            <div class="col-lg-4 d-flex justify-content-center">
              <div class="item d-flex align-items-center">
                <div class="icon"><i class="icon-headphones"></i></div>
                <div class="text">
                  <h6 class="no-margin text-uppercase">0817-5175-751</h6>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Main Block -->
      <div class="main-block">
        <div class="container">
          <div class="row">
            <div class="info col-lg-4">
              <div class="logo"><img class="img-fluid" src="assets/img/logo.png" alt="Responsive image"></div>
              
              <ul class="social-menu list-inline">
                <li class="list-inline-item"><a href="#" target="_blank" title="twitter"><i class="fa fa-twitter"></i></a></li>
                <li class="list-inline-item"><a href="#" target="_blank" title="facebook"><i class="fa fa-facebook"></i></a></li>
                <li class="list-inline-item"><a href="#" target="_blank" title="instagram"><i class="fa fa-instagram"></i></a></li>
                <li class="list-inline-item"><a href="#" target="_blank" title="pinterest"><i class="fa fa-pinterest"></i></a></li>
                <li class="list-inline-item"><a href="#" target="_blank" title="vimeo"><i class="fa fa-vimeo"></i></a></li>
              </ul>
            </div>
            <div class="site-links col-lg-2 col-md-6">
              <h5 class="text-uppercase">Shop</h5>
              <ul class="list-unstyled">
                <li> <a href="?page=shop&sort=Atomizer">Atomizer</a></li>
                <li> <a href="?page=shop&sort=Liquid">Liquid</a></li>
                <li> <a href="?page=shop&sort=Accessories">Accessories</a></li>
                <li> <a href="?page=shop&sort=Mod">Mod</a></li>
              </ul>
            </div>
            
            <div class="newsletter col-lg-4">
              <h5 class="text-uppercase">Daily Offers & Discounts</h5>
              <p> Subscribe our email</p>
              <form action="#" id="newsletter-form">
                <div class="form-group">
                  <input type="email" name="subscribermail" placeholder="Your Email Address">
                  <button type="submit"> <i class="fa fa-paper-plane"></i></button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      
    </footer>
    <!-- Javascript files-->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"> </script>
    <script src="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/owl.carousel/owl.carousel.min.js"></script>
    <script src="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/owl.carousel2.thumbs/owl.carousel2.thumbs.min.js"></script>
    <script src="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/bootstrap-select/js/bootstrap-select.min.js"></script>
    <script src="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/vendor/nouislider/nouislider.min.js"></script>
    <script src="https://d32d8xzgnjxuvk.cloudfront.net/hub/1-1/js/front.js"></script>
  </body>
</html>
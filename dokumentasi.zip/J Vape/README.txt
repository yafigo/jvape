berdiri 2016 october 12
terima wholesell
bisa gojek, tokopedia, bukalapak 
rabu : promo mahasiswa (diskon 10% liquid , 5% device atomizer) (KTM)
jumat : promo karyawan (nunjukin employee id)